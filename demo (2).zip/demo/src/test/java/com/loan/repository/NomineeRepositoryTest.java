package com.loan.repository;

import com.loan.entity.Loan;
import com.loan.entity.Nominee;
import com.loan.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:nominee-repo-test;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
        "spring.jpa.hibernate.ddl-auto=create-drop"
})
class NomineeRepositoryTest {

    @Autowired
    private NomineeRepository nomineeRepository;

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    void savePersistsNominee() {
        User user = userRepository.save(User.builder()
                .username("nominee-user")
                .password("password")
                .role("USER")
                .build());
        Loan loan = loanRepository.save(Loan.builder()
                .loanNumber("LN-NOM-1")
                .totalAmount(100000.0)
                .principalOutstanding(95000.0)
                .tenure(36)
                .emiRemaining(34)
                .interestRate(9.0)
                .user(user)
                .build());

        Nominee savedNominee = nomineeRepository.save(Nominee.builder()
                .nomineeName("Chris")
                .relationship("Parent")
                .phone("1234567890")
                .loan(loan)
                .build());

        assertTrue(nomineeRepository.findById(savedNominee.getId()).isPresent());
        assertEquals("Chris", nomineeRepository.findById(savedNominee.getId()).orElseThrow().getNomineeName());
    }
}
