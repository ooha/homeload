package com.loan.repository;

import com.loan.entity.Loan;
import com.loan.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:loan-repo-test;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
        "spring.jpa.hibernate.ddl-auto=create-drop"
})
class LoanRepositoryTest {

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    void findByUserIdReturnsOnlyLoansForRequestedUser() {
        User firstUser = userRepository.save(User.builder()
                .username("first-user")
                .password("password")
                .role("USER")
                .build());
        User secondUser = userRepository.save(User.builder()
                .username("second-user")
                .password("password")
                .role("USER")
                .build());

        loanRepository.save(Loan.builder()
                .loanNumber("LN-1")
                .totalAmount(1000.0)
                .principalOutstanding(800.0)
                .tenure(12)
                .emiRemaining(8)
                .interestRate(7.2)
                .user(firstUser)
                .build());
        loanRepository.save(Loan.builder()
                .loanNumber("LN-2")
                .totalAmount(2000.0)
                .principalOutstanding(1500.0)
                .tenure(18)
                .emiRemaining(12)
                .interestRate(8.1)
                .user(secondUser)
                .build());

        List<Loan> loans = loanRepository.findByUserId(firstUser.getId());

        assertEquals(1, loans.size());
        assertEquals("LN-1", loans.get(0).getLoanNumber());
    }
}
