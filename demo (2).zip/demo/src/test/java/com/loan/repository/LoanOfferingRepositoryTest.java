package com.loan.repository;

import com.loan.entity.LoanOffering;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:loan-offering-repo-test;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
        "spring.jpa.hibernate.ddl-auto=create-drop"
})
class LoanOfferingRepositoryTest {

    @Autowired
    private LoanOfferingRepository loanOfferingRepository;

    @Test
    void savePersistsLoanOffering() {
        LoanOffering savedOffering = loanOfferingRepository.save(LoanOffering.builder()
                .loanType("Personal Loan")
                .interestRate(10.5)
                .maxTenure(60)
                .maxAmount(750000.0)
                .build());

        assertTrue(loanOfferingRepository.findById(savedOffering.getId()).isPresent());
        assertEquals("Personal Loan", loanOfferingRepository.findById(savedOffering.getId()).orElseThrow().getLoanType());
    }
}
