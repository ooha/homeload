package com.loan;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;

import static org.mockito.Mockito.mockStatic;

class HomeloanApplicationTest {

    @Test
    void mainStartsSpringApplication() {
        String[] args = {"--spring.profiles.active=test"};

        try (MockedStatic<SpringApplication> springApplication = mockStatic(SpringApplication.class)) {
            HomeloanApplication.main(args);

            springApplication.verify(() -> SpringApplication.run(HomeloanApplication.class, args));
        }
    }
}
