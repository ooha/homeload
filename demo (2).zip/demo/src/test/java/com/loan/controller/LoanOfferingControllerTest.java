package com.loan.controller;

import com.loan.dto.LoanOfferingRequest;
import com.loan.entity.LoanOffering;
import com.loan.service.LoanOfferingService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoanOfferingControllerTest {

    @Mock
    private LoanOfferingService service;

    @InjectMocks
    private LoanOfferingController loanOfferingController;

    @Test
    void getAllLoanOfferingsReturnsServiceResponse() {
        List<LoanOffering> expectedOfferings = List.of(
                LoanOffering.builder()
                        .id(1L)
                        .loanType("Home Loan")
                        .interestRate(8.25)
                        .maxTenure(240)
                        .maxAmount(5_000_000.0)
                        .build()
        );

        when(service.getAllLoanOfferings()).thenReturn(expectedOfferings);

        List<LoanOffering> actualOfferings = loanOfferingController.getAllLoanOfferings();

        assertSame(expectedOfferings, actualOfferings);
        verify(service).getAllLoanOfferings();
    }

    @Test
    void createLoanOfferingReturnsServiceResponse() {
        LoanOfferingRequest request = new LoanOfferingRequest();
        request.setLoanType("Car Loan");
        request.setInterestRate(9.1);
        request.setMaxTenure(84);
        request.setMaxAmount(1_500_000.0);

        LoanOffering expectedOffering = LoanOffering.builder()
                .id(2L)
                .loanType("Car Loan")
                .interestRate(9.1)
                .maxTenure(84)
                .maxAmount(1_500_000.0)
                .build();

        when(service.createLoanOffering(request)).thenReturn(expectedOffering);

        LoanOffering actualOffering = loanOfferingController.createLoanOffering(request);

        assertSame(expectedOffering, actualOffering);
        verify(service).createLoanOffering(request);
    }
}
