package com.loan.controller;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanTrackerResponse;
import com.loan.entity.Loan;
import com.loan.service.LoanService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoanControllerTest {

    @Mock
    private LoanService loanService;

    @InjectMocks
    private LoanController loanController;

    @Test
    void applyLoanReturnsServiceResponse() {
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(1L);
        request.setOfferingId(2L);
        request.setLoanAmount(50000.0);
        request.setTenure(24);

        Loan expectedLoan = Loan.builder()
                .id(10L)
                .loanNumber("LN-1001")
                .totalAmount(50000.0)
                .principalOutstanding(48000.0)
                .tenure(24)
                .emiRemaining(20)
                .interestRate(8.5)
                .build();

        when(loanService.applyLoan(request)).thenReturn(expectedLoan);

        Loan actualLoan = loanController.applyLoan(request);

        assertSame(expectedLoan, actualLoan);
        verify(loanService).applyLoan(request);
    }

    @Test
    void getLoansByUserReturnsServiceResponse() {
        Long userId = 5L;
        List<Loan> expectedLoans = List.of(
                Loan.builder().id(1L).loanNumber("LN-1").build(),
                Loan.builder().id(2L).loanNumber("LN-2").build()
        );

        when(loanService.getLoansByUser(userId)).thenReturn(expectedLoans);

        List<Loan> actualLoans = loanController.getLoansByUser(userId);

        assertSame(expectedLoans, actualLoans);
        verify(loanService).getLoansByUser(userId);
    }

    @Test
    void getLoanDetailsReturnsServiceResponse() {
        Long loanId = 7L;
        Loan expectedLoan = Loan.builder()
                .id(loanId)
                .loanNumber("LN-7")
                .build();

        when(loanService.getLoanDetails(loanId)).thenReturn(expectedLoan);

        Loan actualLoan = loanController.getLoanDetails(loanId);

        assertSame(expectedLoan, actualLoan);
        verify(loanService).getLoanDetails(loanId);
    }

    @Test
    void addNomineeDelegatesToServiceAndReturnsSuccessMessage() {
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(9L);
        request.setNomineeName("Alex");
        request.setRelationship("Sibling");
        request.setPhone("5551234567");

        doNothing().when(loanService).addNominee(request);

        String response = loanController.addNominee(request);

        assertEquals("Nominee added successfully", response);
        verify(loanService).addNominee(request);
    }

    @Test
    void getAllLoansReturnsServiceResponse() {
        List<Loan> expectedLoans = List.of(
                Loan.builder().id(3L).loanNumber("LN-3").build()
        );

        when(loanService.getAllLoans()).thenReturn(expectedLoans);

        List<Loan> actualLoans = loanController.getAllLoans();

        assertSame(expectedLoans, actualLoans);
        verify(loanService).getAllLoans();
    }

    @Test
    void getLoanTrackerReturnsServiceResponse() {
        Long loanId = 11L;
        LoanTrackerResponse expectedTracker = LoanTrackerResponse.builder()
                .loanNumber("LN-11")
                .loanAmount(100000.0)
                .principalOutstanding(75000.0)
                .interestRate(7.25)
                .emiRemaining(18)
                .build();

        when(loanService.getLoanTracker(loanId)).thenReturn(expectedTracker);

        LoanTrackerResponse actualTracker = loanController.getLoanTracker(loanId);

        assertSame(expectedTracker, actualTracker);
        verify(loanService).getLoanTracker(loanId);
    }
}
