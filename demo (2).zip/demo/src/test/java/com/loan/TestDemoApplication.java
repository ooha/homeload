package com.loan;

import org.springframework.boot.SpringApplication;

public class TestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.from(HomeloanApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
