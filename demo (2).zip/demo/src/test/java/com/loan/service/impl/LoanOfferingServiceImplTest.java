package com.loan.service.impl;

import com.loan.dto.LoanOfferingRequest;
import com.loan.entity.LoanOffering;
import com.loan.repository.LoanOfferingRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoanOfferingServiceImplTest {

    @Mock
    private LoanOfferingRepository repository;

    @InjectMocks
    private LoanOfferingServiceImpl loanOfferingService;

    @Test
    void getAllLoanOfferingsReturnsRepositoryResults() {
        List<LoanOffering> expectedOfferings = List.of(
                LoanOffering.builder().id(1L).loanType("Home Loan").build()
        );
        when(repository.findAll()).thenReturn(expectedOfferings);

        List<LoanOffering> actualOfferings = loanOfferingService.getAllLoanOfferings();

        assertSame(expectedOfferings, actualOfferings);
    }

    @Test
    void createLoanOfferingSavesMappedOffering() {
        LoanOfferingRequest request = new LoanOfferingRequest();
        request.setLoanType("Education Loan");
        request.setInterestRate(6.8);
        request.setMaxTenure(96);
        request.setMaxAmount(2_000_000.0);

        LoanOffering savedOffering = LoanOffering.builder()
                .id(7L)
                .loanType("Education Loan")
                .interestRate(6.8)
                .maxTenure(96)
                .maxAmount(2_000_000.0)
                .build();
        when(repository.save(org.mockito.ArgumentMatchers.any(LoanOffering.class))).thenReturn(savedOffering);

        LoanOffering result = loanOfferingService.createLoanOffering(request);

        ArgumentCaptor<LoanOffering> offeringCaptor = ArgumentCaptor.forClass(LoanOffering.class);
        verify(repository).save(offeringCaptor.capture());
        LoanOffering persistedOffering = offeringCaptor.getValue();
        assertEquals("Education Loan", persistedOffering.getLoanType());
        assertEquals(6.8, persistedOffering.getInterestRate());
        assertEquals(96, persistedOffering.getMaxTenure());
        assertEquals(2_000_000.0, persistedOffering.getMaxAmount());
        assertSame(savedOffering, result);
    }
}
