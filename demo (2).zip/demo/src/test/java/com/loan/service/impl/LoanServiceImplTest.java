package com.loan.service.impl;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanTrackerResponse;
import com.loan.entity.Loan;
import com.loan.entity.LoanOffering;
import com.loan.entity.Nominee;
import com.loan.entity.User;
import com.loan.repository.LoanOfferingRepository;
import com.loan.repository.LoanRepository;
import com.loan.repository.NomineeRepository;
import com.loan.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoanServiceImplTest {

    @Mock
    private LoanRepository loanRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private LoanOfferingRepository offeringRepository;

    @Mock
    private NomineeRepository nomineeRepository;

    @InjectMocks
    private LoanServiceImpl loanService;

    @Test
    void applyLoanSavesMappedLoan() {
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(1L);
        request.setOfferingId(2L);
        request.setLoanAmount(250000.0);
        request.setTenure(120);

        User user = User.builder()
                .id(1L)
                .username("alice")
                .password("secret")
                .role("USER")
                .build();
        LoanOffering offering = LoanOffering.builder()
                .id(2L)
                .loanType("Home Loan")
                .interestRate(7.75)
                .maxTenure(240)
                .maxAmount(1_000_000.0)
                .build();
        Loan savedLoan = Loan.builder()
                .id(99L)
                .loanNumber("generated")
                .totalAmount(250000.0)
                .principalOutstanding(250000.0)
                .tenure(120)
                .emiRemaining(120)
                .interestRate(7.75)
                .user(user)
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(offeringRepository.findById(2L)).thenReturn(Optional.of(offering));
        when(loanRepository.save(org.mockito.ArgumentMatchers.any(Loan.class))).thenReturn(savedLoan);

        Loan result = loanService.applyLoan(request);

        ArgumentCaptor<Loan> loanCaptor = ArgumentCaptor.forClass(Loan.class);
        verify(loanRepository).save(loanCaptor.capture());
        Loan persistedLoan = loanCaptor.getValue();
        assertNotNull(persistedLoan.getLoanNumber());
        assertEquals(250000.0, persistedLoan.getTotalAmount());
        assertEquals(250000.0, persistedLoan.getPrincipalOutstanding());
        assertEquals(120, persistedLoan.getTenure());
        assertEquals(120, persistedLoan.getEmiRemaining());
        assertEquals(7.75, persistedLoan.getInterestRate());
        assertSame(offering, persistedLoan.getOffering());
        assertSame(user, persistedLoan.getUser());
        assertSame(savedLoan, result);
    }

    @Test
    void applyLoanThrowsWhenUserMissing() {
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(1L);
        request.setOfferingId(2L);

        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loanService.applyLoan(request));

        assertEquals("User not found", exception.getMessage());
    }

    @Test
    void applyLoanThrowsWhenOfferingMissing() {
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(1L);
        request.setOfferingId(2L);

        when(userRepository.findById(1L)).thenReturn(Optional.of(User.builder().id(1L).build()));
        when(offeringRepository.findById(2L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loanService.applyLoan(request));

        assertEquals("Loan offering not found", exception.getMessage());
    }

    @Test
    void getLoansByUserReturnsRepositoryResults() {
        List<Loan> expectedLoans = List.of(Loan.builder().id(1L).loanNumber("LN-1").build());

        when(loanRepository.findByUserId(4L)).thenReturn(expectedLoans);

        List<Loan> actualLoans = loanService.getLoansByUser(4L);

        assertSame(expectedLoans, actualLoans);
    }

    @Test
    void getLoanDetailsReturnsRepositoryResult() {
        Loan expectedLoan = Loan.builder().id(5L).loanNumber("LN-5").build();

        when(loanRepository.findById(5L)).thenReturn(Optional.of(expectedLoan));

        Loan actualLoan = loanService.getLoanDetails(5L);

        assertSame(expectedLoan, actualLoan);
    }

    @Test
    void getLoanDetailsThrowsWhenMissing() {
        when(loanRepository.findById(5L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loanService.getLoanDetails(5L));

        assertEquals("Loan not found", exception.getMessage());
    }

    @Test
    void addNomineeSavesMappedNominee() {
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(10L);
        request.setNomineeName("Sam");
        request.setRelationship("Brother");
        request.setPhone("9999999999");

        Loan loan = Loan.builder().id(10L).loanNumber("LN-10").build();
        when(loanRepository.findById(10L)).thenReturn(Optional.of(loan));

        loanService.addNominee(request);

        ArgumentCaptor<Nominee> nomineeCaptor = ArgumentCaptor.forClass(Nominee.class);
        verify(nomineeRepository).save(nomineeCaptor.capture());
        Nominee nominee = nomineeCaptor.getValue();
        assertEquals("Sam", nominee.getNomineeName());
        assertEquals("Brother", nominee.getRelationship());
        assertEquals("9999999999", nominee.getPhone());
        assertSame(loan, nominee.getLoan());
    }

    @Test
    void addNomineeThrowsWhenLoanMissing() {
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(10L);

        when(loanRepository.findById(10L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loanService.addNominee(request));

        assertEquals("Loan not found", exception.getMessage());
    }

    @Test
    void getAllLoansReturnsRepositoryResults() {
        List<Loan> expectedLoans = List.of(Loan.builder().id(1L).build());
        when(loanRepository.findAll()).thenReturn(expectedLoans);

        List<Loan> actualLoans = loanService.getAllLoans();

        assertSame(expectedLoans, actualLoans);
    }

    @Test
    void getLoanTrackerReturnsMappedResponse() {
        Loan loan = Loan.builder()
                .id(12L)
                .loanNumber("LN-12")
                .totalAmount(300000.0)
                .principalOutstanding(275000.0)
                .interestRate(8.1)
                .emiRemaining(54)
                .build();
        when(loanRepository.findById(12L)).thenReturn(Optional.of(loan));

        LoanTrackerResponse tracker = loanService.getLoanTracker(12L);

        assertEquals("LN-12", tracker.getLoanNumber());
        assertEquals(300000.0, tracker.getLoanAmount());
        assertEquals(275000.0, tracker.getPrincipalOutstanding());
        assertEquals(8.1, tracker.getInterestRate());
        assertEquals(54, tracker.getEmiRemaining());
    }

    @Test
    void getLoanTrackerThrowsWhenLoanMissing() {
        when(loanRepository.findById(12L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loanService.getLoanTracker(12L));

        assertEquals("Loan not found", exception.getMessage());
    }
}
