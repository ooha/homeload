package com.loan.repository;

import com.loan.entity.LoanOffering;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanOfferingRepository extends JpaRepository<LoanOffering, Long> {
}