package com.loan.repository;

import com.loan.entity.Nominee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NomineeRepository extends JpaRepository<Nominee, Long> {

    java.util.Optional<Nominee> findByLoanId(Long loanId);
}
