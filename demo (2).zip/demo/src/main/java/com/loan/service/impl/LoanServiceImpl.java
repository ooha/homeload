package com.loan.service.impl;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanTrackerResponse;
import com.loan.entity.Loan;
import com.loan.entity.LoanOffering;
import com.loan.entity.Nominee;
import com.loan.entity.User;
import com.loan.repository.LoanRepository;
import com.loan.repository.LoanOfferingRepository;
import com.loan.repository.NomineeRepository;
import com.loan.repository.UserRepository;
import com.loan.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class LoanServiceImpl implements LoanService {

    private final LoanRepository loanRepository;
    private final UserRepository userRepository;
    private final LoanOfferingRepository offeringRepository;
    private final NomineeRepository nomineeRepository;
    @Override
    public Loan applyLoan(ApplyLoanRequest request) {

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        LoanOffering offering = offeringRepository.findById(request.getOfferingId())
                .orElseThrow(() -> new RuntimeException("Loan offering not found"));

        Loan loan = Loan.builder()
                .loanNumber(UUID.randomUUID().toString())
                .totalAmount(request.getLoanAmount())
                .principalOutstanding(request.getLoanAmount())
                .tenure(request.getTenure())
                .emiRemaining(request.getTenure())
                .interestRate(offering.getInterestRate())
                .offering(offering)
                .user(user)
                .build();

        return loanRepository.save(loan);
    }

    @Override
    public List<Loan> getLoansByUser(Long userId) {
        return loanRepository.findByUserId(userId);
    }

    @Override
    public Loan getLoanDetails(Long loanId) {

        return loanRepository.findById(loanId)
                .orElseThrow(() -> new RuntimeException("Loan not found"));
    }

    @Override
    public void addNominee(AddNomineeRequest request) {

        Loan loan = loanRepository.findById(request.getLoanId())
                .orElseThrow(() -> new RuntimeException("Loan not found"));

        Nominee nominee = Nominee.builder()
                .nomineeName(request.getNomineeName())
                .relationship(request.getRelationship())
                .phone(request.getPhone())
                .loan(loan)
                .build();

        nomineeRepository.save(nominee);
    }

    @Override
    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }
    @Override
    public LoanTrackerResponse getLoanTracker(Long loanId) {

        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new RuntimeException("Loan not found"));

        return LoanTrackerResponse.builder()
                .loanNumber(loan.getLoanNumber())
                .loanAmount(loan.getTotalAmount())
                .principalOutstanding(loan.getPrincipalOutstanding())
                .interestRate(loan.getInterestRate())
                .emiRemaining(loan.getEmiRemaining())
                .build();
    }
}
