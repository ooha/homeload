package com.loan.service;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanTrackerResponse;
import com.loan.entity.Loan;

import java.util.List;

public interface LoanService {

    Loan applyLoan(ApplyLoanRequest request);

    List<Loan> getLoansByUser(Long userId);

    Loan getLoanDetails(Long loanId);

    void addNominee(AddNomineeRequest request);

    List<Loan> getAllLoans();

    LoanTrackerResponse getLoanTracker(Long loanId);
}