package com.loan.service;

import com.loan.dto.LoanOfferingRequest;
import com.loan.entity.LoanOffering;
import java.util.List;

public interface LoanOfferingService {

    LoanOffering createLoanOffering(LoanOfferingRequest request);

    List<LoanOffering> getAllLoanOfferings();
}