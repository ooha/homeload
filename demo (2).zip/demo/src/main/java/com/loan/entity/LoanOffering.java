package com.loan.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "loan_offerings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanOffering {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "loan_type")
    private String loanType;

    @Column(name = "interest_rate")
    private double interestRate;

    @Column(name = "max_tenure")
    private int maxTenure;

    @Column(name = "max_amount")
    private double maxAmount;
}