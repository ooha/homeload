package com.loan.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "nominees")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Nominee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomineeName;

    private String relationship;

    private String phone;

    @OneToOne
    @JoinColumn(name = "loan_id")
    private Loan loan;
}