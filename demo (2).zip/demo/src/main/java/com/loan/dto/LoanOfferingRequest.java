package com.loan.dto;

import lombok.Data;

@Data
public class LoanOfferingRequest {

    private String loanType;
    private double interestRate;
    private int maxTenure;
    private double maxAmount;
}