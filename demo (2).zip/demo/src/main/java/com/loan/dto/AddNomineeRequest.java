package com.loan.dto;

import lombok.Data;

@Data
public class AddNomineeRequest {

    private Long loanId;
    private String nomineeName;
    private String relationship;
    private String phone;
}