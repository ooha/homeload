package com.loan.dto;

import lombok.Data;

@Data
public class ApplyLoanRequest {

    private Long userId;

    private Long offeringId;

    private double loanAmount;

    private int tenure;
}