package com.loan.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoanTrackerResponse {

    private String loanNumber;

    private Double loanAmount;

    private Double principalOutstanding;

    private Double interestRate;

    private Integer emiRemaining;

}