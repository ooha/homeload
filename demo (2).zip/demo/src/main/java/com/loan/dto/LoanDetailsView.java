package com.loan.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoanDetailsView {

    private Long loanId;
    private String loanNumber;
    private String loanType;
    private String nomineeName;
    private String nomineeRelationship;
    private String nomineePhone;
    private Double totalLoanAmount;
    private Integer loanTenure;
    private Double currentInterestRate;
    private Double principalOutstandingAmount;
    private Integer outstandingEmiCount;
}
