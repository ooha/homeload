package com.loan.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http

                // disable csrf for REST APIs
                .csrf(csrf -> csrf.disable())

                // authorization rules
                .authorizeHttpRequests(auth -> auth

                        // public endpoints
                        .requestMatchers("/css/**", "/login").permitAll()
                        .requestMatchers("/api/loan-offerings/**").permitAll()

                        // admin endpoints
                        .requestMatchers("/api/loans/admin/**").hasRole("ADMIN")

                        // user endpoints
                        .requestMatchers("/", "/ui", "/ui/**").authenticated()
                        .requestMatchers("/api/loans/**").hasAnyRole("USER","ADMIN")

                        // everything else requires login
                        .anyRequest().authenticated()
                )

                .formLogin(Customizer.withDefaults())

                // basic authentication
                .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}
