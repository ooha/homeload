package com.loan.controller;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanDetailsView;
import com.loan.entity.Loan;
import com.loan.entity.Nominee;
import com.loan.repository.NomineeRepository;
import com.loan.service.LoanOfferingService;
import com.loan.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class ViewController {

    private final LoanService loanService;
    private final LoanOfferingService loanOfferingService;
    private final NomineeRepository nomineeRepository;

    @GetMapping({"/", "/ui"})
    public String home(@RequestParam(required = false) Long userId,
                       @RequestParam(required = false) Long loanId,
                       @RequestParam(required = false) Long detailsLoanId,
                       Model model) {
        model.addAttribute("offerings", loanOfferingService.getAllLoanOfferings());
        model.addAttribute("applyLoanRequest", new ApplyLoanRequest());
        model.addAttribute("addNomineeRequest", new AddNomineeRequest());
        model.addAttribute("selectedUserId", userId);
        model.addAttribute("selectedLoanId", loanId);
        model.addAttribute("selectedDetailsLoanId", detailsLoanId);

        if (userId != null) {
            model.addAttribute("userLoans", loanService.getLoansByUser(userId));
        }

        if (loanId != null) {
            model.addAttribute("tracker", loanService.getLoanTracker(loanId));
        }

        if (detailsLoanId != null) {
            model.addAttribute("loanDetails", buildLoanDetails(detailsLoanId));
        }

        return "index";
    }

    @PostMapping("/ui/apply")
    public String applyLoan(@ModelAttribute ApplyLoanRequest request, Model model) {
        try {
            Loan loan = loanService.applyLoan(request);
            model.addAttribute("successMessage", "Loan application submitted. Loan ID: " + loan.getId());
            return home(request.getUserId(), loan.getId(), loan.getId(), model);
        } catch (RuntimeException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return home(request.getUserId(), null, null, model);
        }
    }

    @PostMapping("/ui/nominee")
    public String addNominee(@ModelAttribute AddNomineeRequest request, Model model) {
        try {
            loanService.addNominee(request);
            model.addAttribute("successMessage", "Nominee added successfully.");
            return home(null, request.getLoanId(), request.getLoanId(), model);
        } catch (RuntimeException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return home(null, request.getLoanId(), request.getLoanId(), model);
        }
    }

    @GetMapping("/ui/loans")
    public String viewLoansByUser(@RequestParam Long userId, Model model) {
        return home(userId, null, null, model);
    }

    @GetMapping("/ui/tracker")
    public String viewTracker(@RequestParam Long loanId, Model model) {
        return home(null, loanId, null, model);
    }

    @GetMapping("/ui/loan")
    public String viewLoanDetails(@RequestParam Long loanId, Model model) {
        return home(null, null, loanId, model);
    }

    private LoanDetailsView buildLoanDetails(Long loanId) {
        Loan loan = loanService.getLoanDetails(loanId);
        Nominee nominee = nomineeRepository.findByLoanId(loanId).orElse(null);

        return LoanDetailsView.builder()
                .loanId(loan.getId())
                .loanNumber(loan.getLoanNumber())
                .loanType(loan.getOffering() != null ? loan.getOffering().getLoanType() : "Not available")
                .nomineeName(nominee != null ? nominee.getNomineeName() : "Not added")
                .nomineeRelationship(nominee != null ? nominee.getRelationship() : "Not added")
                .nomineePhone(nominee != null ? nominee.getPhone() : "Not added")
                .totalLoanAmount(loan.getTotalAmount())
                .loanTenure(loan.getTenure())
                .currentInterestRate(loan.getInterestRate())
                .principalOutstandingAmount(loan.getPrincipalOutstanding())
                .outstandingEmiCount(loan.getEmiRemaining())
                .build();
    }
}
