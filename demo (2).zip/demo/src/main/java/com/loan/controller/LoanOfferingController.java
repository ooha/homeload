package com.loan.controller;

import com.loan.dto.LoanOfferingRequest;
import com.loan.entity.LoanOffering;
import com.loan.service.LoanOfferingService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loan-offerings")
public class LoanOfferingController {

    private final LoanOfferingService service;

    public LoanOfferingController(LoanOfferingService service) {
        this.service = service;
    }

    @GetMapping
    public List<LoanOffering> getAllLoanOfferings() {
        return service.getAllLoanOfferings();
    }

    @PostMapping
    public LoanOffering createLoanOffering(@RequestBody LoanOfferingRequest request) {
        return service.createLoanOffering(request);
    }
}