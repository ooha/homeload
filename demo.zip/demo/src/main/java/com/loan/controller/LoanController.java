package com.loan.controller;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.entity.Loan;
import com.loan.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@RequiredArgsConstructor
public class LoanController {

    private final LoanService loanService;

    @PostMapping("/apply")
    public Loan applyLoan(@RequestBody ApplyLoanRequest request) {
        return loanService.applyLoan(request);
    }

    @GetMapping("/user/{userId}")
    public List<Loan> getLoansByUser(@PathVariable Long userId) {
        return loanService.getLoansByUser(userId);
    }

    @GetMapping("/{loanId}")
    public Loan getLoanDetails(@PathVariable Long loanId) {
        return loanService.getLoanDetails(loanId);
    }

    @PostMapping("/nominee")
    public String addNominee(@RequestBody AddNomineeRequest request) {

        loanService.addNominee(request);

        return "Nominee added successfully";
    }

    @GetMapping("/admin/all")
    public List<Loan> getAllLoans() {
        return loanService.getAllLoans();
    }
}