package com.loan.service.impl;

import com.loan.dto.LoanOfferingRequest;
import com.loan.entity.LoanOffering;
import com.loan.repository.LoanOfferingRepository;
import com.loan.service.LoanOfferingService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanOfferingServiceImpl implements LoanOfferingService {

    private final LoanOfferingRepository repository;

    public LoanOfferingServiceImpl(LoanOfferingRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<LoanOffering> getAllLoanOfferings() {
        return repository.findAll();
    }

    @Override
    public LoanOffering createLoanOffering(LoanOfferingRequest request) {

        LoanOffering offering = LoanOffering.builder()
                .loanType(request.getLoanType())
                .interestRate(request.getInterestRate())
                .maxTenure(request.getMaxTenure())
                .maxAmount(request.getMaxAmount())
                .build();

        return repository.save(offering);
    }
}
