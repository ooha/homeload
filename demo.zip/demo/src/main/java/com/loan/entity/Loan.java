package com.loan.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "loans")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "loan_number", unique = true)
    private String loanNumber;

    @Column(name = "total_amount")
    private double totalAmount;

    @Column(name = "principal_outstanding")
    private double principalOutstanding;

    @Column(name = "tenure")
    private int tenure;

    @Column(name = "emi_remaining")
    private int emiRemaining;

    @Column(name = "interest_rate")
    private double interestRate;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}