package com.loan.controller;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanDetailsView;
import com.loan.entity.Loan;
import com.loan.entity.Nominee;
import com.loan.entity.User;
import com.loan.repository.NomineeRepository;
import com.loan.repository.UserRepository;
import com.loan.service.LoanOfferingService;
import com.loan.service.LoanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.security.core.Authentication;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class ViewController {

    private final LoanService loanService;
    private final LoanOfferingService loanOfferingService;
    private final NomineeRepository nomineeRepository;
    private final UserRepository userRepository;

    @GetMapping({"/", "/ui"})
    public String home(@RequestParam(required = false) Long userId,
                       @RequestParam(required = false) Long loanId,
                       @RequestParam(required = false) Long detailsLoanId,
                       Authentication authentication,
                       Model model) {
        User currentUser = getCurrentUser(authentication);
        boolean admin = isAdmin(authentication);
        Long effectiveUserId = admin ? userId : currentUser.getId();

        model.addAttribute("offerings", loanOfferingService.getAllLoanOfferings());
        model.addAttribute("applyLoanRequest", new ApplyLoanRequest());
        model.addAttribute("addNomineeRequest", new AddNomineeRequest());
        model.addAttribute("selectedUserId", effectiveUserId);
        model.addAttribute("selectedLoanId", loanId);
        model.addAttribute("selectedDetailsLoanId", detailsLoanId);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("isAdmin", admin);

        if (effectiveUserId != null) {
            model.addAttribute("userLoans", loanService.getLoansByUser(effectiveUserId));
        }

        if (loanId != null) {
            assertLoanAccess(loanId, currentUser, admin);
            model.addAttribute("tracker", loanService.getLoanTracker(loanId));
        }

        if (detailsLoanId != null) {
            assertLoanAccess(detailsLoanId, currentUser, admin);
            model.addAttribute("loanDetails", buildLoanDetails(detailsLoanId));
        }

        return "index";
    }

    @PostMapping("/ui/apply")
    public String applyLoan(@ModelAttribute ApplyLoanRequest request,
                            Authentication authentication,
                            Model model) {
        User currentUser = getCurrentUser(authentication);
        boolean admin = isAdmin(authentication);
        request.setUserId(resolveUserId(request.getUserId(), currentUser, admin));

        try {
            Loan loan = loanService.applyLoan(request);
            model.addAttribute("successMessage", "Loan application submitted. Loan ID: " + loan.getId());
            return home(request.getUserId(), loan.getId(), loan.getId(), authentication, model);
        } catch (RuntimeException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return home(request.getUserId(), null, null, authentication, model);
        }
    }

    @PostMapping("/ui/nominee")
    public String addNominee(@ModelAttribute AddNomineeRequest request,
                             Authentication authentication,
                             Model model) {
        User currentUser = getCurrentUser(authentication);
        boolean admin = isAdmin(authentication);

        try {
            assertLoanAccess(request.getLoanId(), currentUser, admin);
            loanService.addNominee(request);
            model.addAttribute("successMessage", "Nominee added successfully.");
            return home(admin ? null : currentUser.getId(), request.getLoanId(), request.getLoanId(), authentication, model);
        } catch (RuntimeException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            Long visibleLoanId = ex instanceof AccessDeniedException ? null : request.getLoanId();
            return home(admin ? null : currentUser.getId(), visibleLoanId, visibleLoanId, authentication, model);
        }
    }

    @GetMapping("/ui/loans")
    public String viewLoansByUser(@RequestParam(required = false) Long userId,
                                  Authentication authentication,
                                  Model model) {
        return home(userId, null, null, authentication, model);
    }

    @GetMapping("/ui/tracker")
    public String viewTracker(@RequestParam Long loanId,
                              Authentication authentication,
                              Model model) {
        return home(null, loanId, null, authentication, model);
    }

    @GetMapping("/ui/loan")
    public String viewLoanDetails(@RequestParam Long loanId,
                                  Authentication authentication,
                                  Model model) {
        return home(null, null, loanId, authentication, model);
    }

    private LoanDetailsView buildLoanDetails(Long loanId) {
        Loan loan = loanService.getLoanDetails(loanId);
        Nominee nominee = nomineeRepository.findAllByLoanIdOrderByIdDesc(loanId).stream()
                .findFirst()
                .orElse(null);

        return LoanDetailsView.builder()
                .loanId(loan.getId())
                .loanNumber(loan.getLoanNumber())
                .loanType(loan.getOffering() != null ? loan.getOffering().getLoanType() : "Not available")
                .nomineeName(nominee != null ? nominee.getNomineeName() : "Not added")
                .nomineeRelationship(nominee != null ? nominee.getRelationship() : "Not added")
                .nomineePhone(nominee != null ? nominee.getPhone() : "Not added")
                .totalLoanAmount(loan.getTotalAmount())
                .loanTenure(loan.getTenure())
                .currentInterestRate(loan.getInterestRate())
                .principalOutstandingAmount(loan.getPrincipalOutstanding())
                .outstandingEmiCount(loan.getEmiRemaining())
                .build();
    }

    private User getCurrentUser(Authentication authentication) {
        return userRepository.findByUsername(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Logged in user not found"));
    }

    private boolean isAdmin(Authentication authentication) {
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> "ROLE_ADMIN".equals(authority.getAuthority()));
    }

    private Long resolveUserId(Long requestedUserId, User currentUser, boolean admin) {
        if (!admin) {
            return currentUser.getId();
        }
        return requestedUserId != null ? requestedUserId : currentUser.getId();
    }

    private void assertLoanAccess(Long loanId, User currentUser, boolean admin) {
        if (admin) {
            return;
        }

        Loan loan = loanService.getLoanDetails(loanId);
        if (loan.getUser() == null || !currentUser.getId().equals(loan.getUser().getId())) {
            throw new AccessDeniedException("You can only access your own loan details.");
        }
    }
}
