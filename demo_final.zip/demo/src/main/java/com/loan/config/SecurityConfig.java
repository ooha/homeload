package com.loan.config;

import com.loan.entity.User;
import com.loan.repository.UserRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public UserDetailsService userDetailsService(UserRepository userRepository) {
        return username -> {
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

            return org.springframework.security.core.userdetails.User.builder()
                    .username(user.getUsername())
                    .password(user.getPassword())
                    .authorities(List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole())))
                    .build();
        };
    }

    @Bean
    @SuppressWarnings("deprecation")
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http

                // disable csrf for REST APIs
                .csrf(csrf -> csrf.disable())

                // authorization rules
                .authorizeHttpRequests(auth -> auth

                        // public endpoints
                        .requestMatchers("/css/**", "/login").permitAll()
                        .requestMatchers("/api/loan-offerings/**").permitAll()

                        // admin endpoints
                        .requestMatchers("/api/loans/admin/**").hasRole("ADMIN")

                        // user endpoints
                        .requestMatchers("/", "/ui", "/ui/**").authenticated()
                        .requestMatchers("/api/loans/**").hasAnyRole("USER","ADMIN")

                        // everything else requires login
                        .anyRequest().authenticated()
                )

                .formLogin(Customizer.withDefaults())

                // basic authentication
                .httpBasic(httpBasic -> httpBasic.disable());

        return http.build();
    }
}
