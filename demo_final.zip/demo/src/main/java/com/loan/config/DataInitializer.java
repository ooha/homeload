package com.loan.config;

import com.loan.entity.User;
import com.loan.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        createUserIfMissing("user", "user123", "USER");
        createUserIfMissing("admin", "admin123", "ADMIN");
    }

    private void createUserIfMissing(String username, String rawPassword, String role) {
        if (userRepository.findByUsername(username).isPresent()) {
            return;
        }

        userRepository.save(User.builder()
                .username(username)
                .password(rawPassword)
                .role(role)
                .build());
    }
}
