package com.loan.controller;

import com.loan.dto.AddNomineeRequest;
import com.loan.dto.ApplyLoanRequest;
import com.loan.dto.LoanDetailsView;
import com.loan.dto.LoanTrackerResponse;
import com.loan.entity.Loan;
import com.loan.entity.LoanOffering;
import com.loan.entity.Nominee;
import com.loan.entity.User;
import com.loan.repository.NomineeRepository;
import com.loan.repository.UserRepository;
import com.loan.service.LoanOfferingService;
import com.loan.service.LoanService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ViewControllerTest {

    @Mock
    private LoanService loanService;

    @Mock
    private LoanOfferingService loanOfferingService;

    @Mock
    private NomineeRepository nomineeRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private ViewController viewController;

    @Test
    void homeLoadsLoggedInUsersLoansForRegularUser() {
        User currentUser = dbUser(4L, "user", "USER");
        Loan loan = loanOwnedBy(8L, currentUser);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of(LoanOffering.builder().id(1L).loanType("Home Loan").build()));
        when(loanService.getLoansByUser(4L)).thenReturn(List.of(loan));

        String viewName = viewController.home(99L, null, null, auth("user", "ROLE_USER"), model);

        assertEquals("index", viewName);
        assertEquals(currentUser, model.getAttribute("currentUser"));
        assertEquals(false, model.getAttribute("isAdmin"));
        assertEquals(4L, model.getAttribute("selectedUserId"));
        assertEquals(List.of(loan), model.getAttribute("userLoans"));
        verify(loanService).getLoansByUser(4L);
    }

    @Test
    void homeLetsAdminLoadRequestedUsersLoansAndDetails() {
        User admin = dbUser(1L, "admin", "ADMIN");
        User borrower = dbUser(7L, "borrower", "USER");
        LoanOffering offering = LoanOffering.builder().id(3L).loanType("Home Loan").build();
        Loan loan = Loan.builder()
                .id(8L)
                .loanNumber("LN-8")
                .offering(offering)
                .totalAmount(500000.0)
                .tenure(240)
                .interestRate(8.25)
                .principalOutstanding(450000.0)
                .emiRemaining(200)
                .user(borrower)
                .build();
        Nominee nominee = Nominee.builder()
                .nomineeName("Chris")
                .relationship("Spouse")
                .phone("9999999999")
                .build();
        LoanTrackerResponse tracker = LoanTrackerResponse.builder()
                .loanNumber("LN-8")
                .loanAmount(500000.0)
                .principalOutstanding(450000.0)
                .interestRate(8.25)
                .emiRemaining(200)
                .build();
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of(offering));
        when(loanService.getLoansByUser(7L)).thenReturn(List.of(loan));
        when(loanService.getLoanTracker(8L)).thenReturn(tracker);
        when(loanService.getLoanDetails(8L)).thenReturn(loan);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(8L)).thenReturn(List.of(nominee));

        String viewName = viewController.home(7L, 8L, 8L, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals(true, model.getAttribute("isAdmin"));
        assertEquals(7L, model.getAttribute("selectedUserId"));
        assertEquals(tracker, model.getAttribute("tracker"));
        LoanDetailsView details = (LoanDetailsView) model.getAttribute("loanDetails");
        assertEquals("Home Loan", details.getLoanType());
        assertEquals("Chris", details.getNomineeName());
    }

    @Test
    void homeLeavesUserSelectionEmptyForAdminWhenNoUserIsRequested() {
        User admin = dbUser(1L, "admin", "ADMIN");
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());

        String viewName = viewController.home(null, null, null, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals(true, model.getAttribute("isAdmin"));
        assertEquals(null, model.getAttribute("selectedUserId"));
    }

    @Test
    void homeRejectsAnotherUsersLoanForRegularUser() {
        User currentUser = dbUser(4L, "user", "USER");
        User otherUser = dbUser(5L, "other", "USER");
        Loan otherLoan = loanOwnedBy(10L, otherUser);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(4L)).thenReturn(List.of());
        when(loanService.getLoanDetails(10L)).thenReturn(otherLoan);

        AccessDeniedException exception = assertThrows(AccessDeniedException.class,
                () -> viewController.home(null, 10L, null, auth("user", "ROLE_USER"), model));

        assertEquals("You can only access your own loan details.", exception.getMessage());
    }

    @Test
    void applyLoanUsesLoggedInUserForRegularUser() {
        User currentUser = dbUser(6L, "user", "USER");
        LoanOffering offering = LoanOffering.builder().id(2L).loanType("Home Loan").build();
        Loan loan = loanOwnedBy(15L, currentUser);
        loan.setOffering(offering);
        loan.setTotalAmount(300000.0);
        loan.setTenure(180);
        loan.setInterestRate(8.0);
        loan.setPrincipalOutstanding(300000.0);
        loan.setEmiRemaining(180);
        LoanTrackerResponse tracker = LoanTrackerResponse.builder()
                .loanNumber("LN-15")
                .loanAmount(300000.0)
                .principalOutstanding(300000.0)
                .interestRate(8.0)
                .emiRemaining(180)
                .build();
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(99L);
        request.setOfferingId(2L);
        request.setLoanAmount(300000.0);
        request.setTenure(180);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanService.applyLoan(request)).thenReturn(loan);
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of(offering));
        when(loanService.getLoansByUser(6L)).thenReturn(List.of(loan));
        when(loanService.getLoanDetails(15L)).thenReturn(loan);
        when(loanService.getLoanTracker(15L)).thenReturn(tracker);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(15L)).thenReturn(List.of());

        String viewName = viewController.applyLoan(request, auth("user", "ROLE_USER"), model);

        assertEquals("index", viewName);
        assertEquals(6L, request.getUserId());
        assertEquals("Loan application submitted. Loan ID: 15", model.getAttribute("successMessage"));
        verify(loanService).applyLoan(request);
    }

    @Test
    void applyLoanKeepsRequestedUserForAdmin() {
        User admin = dbUser(1L, "admin", "ADMIN");
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setUserId(11L);
        request.setOfferingId(2L);
        request.setLoanAmount(100000.0);
        request.setTenure(120);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanService.applyLoan(request)).thenThrow(new RuntimeException("User not found"));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(11L)).thenReturn(List.of());

        String viewName = viewController.applyLoan(request, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals(11L, request.getUserId());
        assertEquals("User not found", model.getAttribute("errorMessage"));
    }

    @Test
    void applyLoanDefaultsAdminToOwnUserWhenRequestDoesNotSpecifyUserId() {
        User admin = dbUser(1L, "admin", "ADMIN");
        ApplyLoanRequest request = new ApplyLoanRequest();
        request.setOfferingId(2L);
        request.setLoanAmount(100000.0);
        request.setTenure(120);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanService.applyLoan(request)).thenThrow(new RuntimeException("Loan offering not found"));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(1L)).thenReturn(List.of());

        String viewName = viewController.applyLoan(request, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals(1L, request.getUserId());
        assertEquals("Loan offering not found", model.getAttribute("errorMessage"));
    }

    @Test
    void addNomineeRejectsAnotherUsersLoanForRegularUser() {
        User currentUser = dbUser(4L, "user", "USER");
        User otherUser = dbUser(5L, "other", "USER");
        Loan otherLoan = loanOwnedBy(20L, otherUser);
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(20L);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(4L)).thenReturn(List.of());
        when(loanService.getLoanDetails(20L)).thenReturn(otherLoan);

        String viewName = viewController.addNominee(request, auth("user", "ROLE_USER"), model);

        assertEquals("index", viewName);
        assertEquals("You can only access your own loan details.", model.getAttribute("errorMessage"));
        verify(loanService, never()).addNominee(request);
    }

    @Test
    void addNomineeAllowsOwnLoanForRegularUser() {
        User currentUser = dbUser(4L, "user", "USER");
        Loan loan = loanOwnedBy(21L, currentUser);
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(21L);
        request.setNomineeName("Jamie");
        request.setRelationship("Parent");
        request.setPhone("8888888888");
        LoanTrackerResponse tracker = LoanTrackerResponse.builder().loanNumber("LN-21").build();
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(4L)).thenReturn(List.of(loan));
        when(loanService.getLoanDetails(21L)).thenReturn(loan);
        when(loanService.getLoanTracker(21L)).thenReturn(tracker);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(21L)).thenReturn(List.of());
        doNothing().when(loanService).addNominee(request);

        String viewName = viewController.addNominee(request, auth("user", "ROLE_USER"), model);

        assertEquals("index", viewName);
        assertEquals("Nominee added successfully.", model.getAttribute("successMessage"));
        verify(loanService).addNominee(request);
    }

    @Test
    void addNomineeShowsServiceErrorForOwnedLoan() {
        User currentUser = dbUser(4L, "user", "USER");
        Loan loan = loanOwnedBy(22L, currentUser);
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(22L);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(4L)).thenReturn(List.of(loan));
        when(loanService.getLoanDetails(22L)).thenReturn(loan);
        when(loanService.getLoanTracker(22L)).thenReturn(LoanTrackerResponse.builder().loanNumber("LN-22").build());
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(22L)).thenReturn(List.of());
        doThrow(new RuntimeException("Loan not found")).when(loanService).addNominee(request);

        String viewName = viewController.addNominee(request, auth("user", "ROLE_USER"), model);

        assertEquals("index", viewName);
        assertEquals("Loan not found", model.getAttribute("errorMessage"));
    }

    @Test
    void addNomineeAllowsAdminForAnyLoan() {
        User admin = dbUser(1L, "admin", "ADMIN");
        User borrower = dbUser(7L, "borrower", "USER");
        Loan loan = loanOwnedBy(30L, borrower);
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(30L);
        request.setNomineeName("Jordan");
        request.setRelationship("Sibling");
        request.setPhone("7777777777");
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoanTracker(30L)).thenReturn(LoanTrackerResponse.builder().loanNumber("LN-30").build());
        when(loanService.getLoanDetails(30L)).thenReturn(loan);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(30L)).thenReturn(List.of());
        doNothing().when(loanService).addNominee(request);

        String viewName = viewController.addNominee(request, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals("Nominee added successfully.", model.getAttribute("successMessage"));
        verify(loanService).addNominee(request);
    }

    @Test
    void addNomineeShowsServiceErrorForAdmin() {
        User admin = dbUser(1L, "admin", "ADMIN");
        User borrower = dbUser(7L, "borrower", "USER");
        Loan loan = loanOwnedBy(31L, borrower);
        AddNomineeRequest request = new AddNomineeRequest();
        request.setLoanId(31L);
        Model model = new ExtendedModelMap();

        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoanTracker(31L)).thenReturn(LoanTrackerResponse.builder().loanNumber("LN-31").build());
        when(loanService.getLoanDetails(31L)).thenReturn(loan);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(31L)).thenReturn(List.of());
        doThrow(new RuntimeException("Loan not found")).when(loanService).addNominee(request);

        String viewName = viewController.addNominee(request, auth("admin", "ROLE_ADMIN"), model);

        assertEquals("index", viewName);
        assertEquals("Loan not found", model.getAttribute("errorMessage"));
    }

    @Test
    void homeRejectsLoanWithoutOwnerForRegularUser() {
        User currentUser = dbUser(4L, "user", "USER");
        Loan orphanLoan = Loan.builder().id(40L).loanNumber("LN-40").build();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(4L)).thenReturn(List.of());
        when(loanService.getLoanDetails(40L)).thenReturn(orphanLoan);

        AccessDeniedException exception = assertThrows(AccessDeniedException.class,
                () -> viewController.home(null, 40L, null, auth("user", "ROLE_USER"), new ExtendedModelMap()));

        assertEquals("You can only access your own loan details.", exception.getMessage());
    }

    @Test
    void helperEndpointsDelegateWithAuthentication() {
        User currentUser = dbUser(3L, "user", "USER");
        Loan ownLoan = loanOwnedBy(9L, currentUser);
        LoanTrackerResponse tracker = LoanTrackerResponse.builder().loanNumber("LN-9").build();

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoansByUser(3L)).thenReturn(List.of(ownLoan));

        Model loansModel = new ExtendedModelMap();
        assertEquals("index", viewController.viewLoansByUser(null, auth("user", "ROLE_USER"), loansModel));
        assertEquals(List.of(ownLoan), loansModel.getAttribute("userLoans"));

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoanDetails(9L)).thenReturn(ownLoan);
        when(loanService.getLoanTracker(9L)).thenReturn(tracker);
        Model trackerModel = new ExtendedModelMap();
        assertEquals("index", viewController.viewTracker(9L, auth("user", "ROLE_USER"), trackerModel));
        assertEquals(tracker, trackerModel.getAttribute("tracker"));

        when(userRepository.findByUsername("user")).thenReturn(Optional.of(currentUser));
        when(loanOfferingService.getAllLoanOfferings()).thenReturn(List.of());
        when(loanService.getLoanDetails(9L)).thenReturn(ownLoan);
        when(nomineeRepository.findAllByLoanIdOrderByIdDesc(9L)).thenReturn(List.of());
        Model detailsModel = new ExtendedModelMap();
        assertEquals("index", viewController.viewLoanDetails(9L, auth("user", "ROLE_USER"), detailsModel));
        assertInstanceOf(LoanDetailsView.class, detailsModel.getAttribute("loanDetails"));
    }

    @Test
    void getCurrentUserFailsWhenAuthenticationMissingFromDatabase() {
        when(userRepository.findByUsername("ghost")).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> viewController.home(null, null, null, auth("ghost", "ROLE_USER"), new ExtendedModelMap()));

        assertTrue(exception.getMessage().contains("Logged in user not found"));
    }

    private Authentication auth(String username, String authority) {
        return new TestingAuthenticationToken(username, "password", authority);
    }

    private User dbUser(Long id, String username, String role) {
        return User.builder()
                .id(id)
                .username(username)
                .password("encoded")
                .role(role)
                .build();
    }

    private Loan loanOwnedBy(Long loanId, User user) {
        return Loan.builder()
                .id(loanId)
                .loanNumber("LN-" + loanId)
                .user(user)
                .build();
    }
}
