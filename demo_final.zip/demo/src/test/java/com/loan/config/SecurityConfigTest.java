package com.loan.config;

import com.loan.entity.User;
import com.loan.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SecurityConfigTest {

    @Mock
    private UserRepository userRepository;

    private final SecurityConfig securityConfig = new SecurityConfig();

    @Test
    void userDetailsServiceLoadsUserFromRepository() {
        when(userRepository.findByUsername("user4")).thenReturn(Optional.of(User.builder()
                .id(4L)
                .username("user4")
                .password("user123")
                .role("USER")
                .build()));

        UserDetailsService service = securityConfig.userDetailsService(userRepository);
        UserDetails userDetails = service.loadUserByUsername("user4");

        assertEquals("user4", userDetails.getUsername());
        assertEquals("user123", userDetails.getPassword());
        assertEquals(1, userDetails.getAuthorities().size());
        assertEquals("ROLE_USER", userDetails.getAuthorities().iterator().next().getAuthority());
    }

    @Test
    void userDetailsServiceThrowsWhenUserMissing() {
        when(userRepository.findByUsername("missing")).thenReturn(Optional.empty());

        UserDetailsService service = securityConfig.userDetailsService(userRepository);

        UsernameNotFoundException exception = assertThrows(UsernameNotFoundException.class,
                () -> service.loadUserByUsername("missing"));

        assertEquals("User not found: missing", exception.getMessage());
    }

    @Test
    @SuppressWarnings("deprecation")
    void passwordEncoderReturnsNoOpInstance() {
        assertSame(org.springframework.security.crypto.password.NoOpPasswordEncoder.getInstance(),
                securityConfig.passwordEncoder());
    }
}
