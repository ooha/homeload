package com.loan.config;

import com.loan.entity.User;
import com.loan.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DataInitializerTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private DataInitializer dataInitializer;

    @Test
    void runCreatesDefaultUsersWhenMissing() {
        when(userRepository.findByUsername("user")).thenReturn(Optional.empty());
        when(userRepository.findByUsername("admin")).thenReturn(Optional.empty());

        dataInitializer.run();

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepository, times(2)).save(userCaptor.capture());
        assertEquals("user", userCaptor.getAllValues().get(0).getUsername());
        assertEquals("user123", userCaptor.getAllValues().get(0).getPassword());
        assertEquals("USER", userCaptor.getAllValues().get(0).getRole());
        assertEquals("admin", userCaptor.getAllValues().get(1).getUsername());
        assertEquals("admin123", userCaptor.getAllValues().get(1).getPassword());
        assertEquals("ADMIN", userCaptor.getAllValues().get(1).getRole());
    }

    @Test
    void runSkipsExistingUsers() {
        when(userRepository.findByUsername("user")).thenReturn(Optional.of(User.builder().username("user").build()));
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(User.builder().username("admin").build()));

        dataInitializer.run();

        verify(userRepository, times(0)).save(org.mockito.ArgumentMatchers.any());
    }
}
