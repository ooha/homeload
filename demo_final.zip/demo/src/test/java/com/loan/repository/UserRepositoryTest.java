package com.loan.repository;

import com.loan.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:user-repo-test;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
        "spring.jpa.hibernate.ddl-auto=create-drop"
})
class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    void savePersistsUser() {
        User savedUser = userRepository.save(User.builder()
                .username("repo-user")
                .password("password")
                .role("USER")
                .build());

        assertTrue(userRepository.findById(savedUser.getId()).isPresent());
        assertEquals("repo-user", userRepository.findById(savedUser.getId()).orElseThrow().getUsername());
    }

    @Test
    void findByUsernameReturnsMatchingUser() {
        userRepository.save(User.builder()
                .username("lookup-user")
                .password("password")
                .role("USER")
                .build());

        assertTrue(userRepository.findByUsername("lookup-user").isPresent());
        assertEquals("lookup-user", userRepository.findByUsername("lookup-user").orElseThrow().getUsername());
    }
}
